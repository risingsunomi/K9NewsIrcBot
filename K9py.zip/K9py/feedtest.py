import feedparser

rss_urls = ['http://english.aljazeera.net/Services/Rss/?PostingId=2007731105943979989',
            'http://feeds.bbci.co.uk/news/rss.xml',
            'http://rss.cnn.com/rss/cnn_topstories.rss',
            'http://feeds.reuters.com/reuters/businessNews',
            'http://rss.slashdot.org/Slashdot/slashdot',
            'http://feeds.wired.com/wired/index?format=xml',
            'http://popsci.com/rss.xml',
            'http://www.telegraph.co.uk/news/picturegalleries/worldnews/rss',
            'http://www.hackinthebox.org/backend.php',
            'http://rss.dw-world.de/rdf/rss-en-all',
            'http://dynamic.feedsportal.com/pf/510578/http://www.pcgamer.com/feed/rss2/',
            'http://www.eluniversal.com.mx/rss/universalmxm.xml',
            'http://www3.nhk.or.jp/rss/news/cat0.xml',
            'http://www.france24.com/fr/monde/rss',
            'http://www.chosun.com/site/data/rss/rss.xml']

for url in rss_urls:
    a = feedparser.parse(url)
    print url
    print a.entries[0].date_parsed
