import time
import sched
import logging
import feedparser
import tinyurl
from concurrent import futures

rss_urls = ['http://english.aljazeera.net/Services/Rss/?PostingId=2007731105943979989',
            'http://feeds.bbci.co.uk/news/rss.xml',
            'http://rss.cnn.com/rss/cnn_topstories.rss',
            'http://feeds.reuters.com/reuters/businessNews',
            'http://rss.slashdot.org/Slashdot/slashdot',
            'http://feeds.wired.com/wired/index?format=xml',
            'http://popsci.com/rss.xml',
            'http://www.telegraph.co.uk/news/picturegalleries/worldnews/rss',
            'http://www.hackinthebox.org/backend.php',
            'http://rss.dw-world.de/rdf/rss-en-all',
            'http://dynamic.feedsportal.com/pf/510578/http://www.pcgamer.com/feed/rss2/',
            'http://www.eluniversal.com.mx/rss/universalmxm.xml',
            'http://www3.nhk.or.jp/rss/news/cat0.xml',
            'http://www.france24.com/fr/monde/rss',
            'http://affaritaliani.libero.it/static/rss/rssGadget.aspx',
            'http://rss.xinhuanet.com/rss/world.xml',
            'http://www.chosun.com/site/data/rss/rss.xml']

def newsfeed():
    entries = []
    with futures.ThreadPoolExecutor(max_workers=13) as executor:
         future_to_url = dict(
            (executor.submit(feedparser.parse, url), url) 
             for url in rss_urls)     
         feeds = [future.result() for future in futures.as_completed(future_to_url)]
         for feed in feeds:
             entries.extend( feed["items"] )
             #print feed["items"]
             for x in entries:
                 print x    
             sorted_entries = sorted(entries, key=lambda entry: entry["date_parsed"], reverse=True)    
             #print rss feed to channel slowly
    entsize = len(sorted_entries)
    print entsize
    for i in range(0, entsize):
        if sorted_entries[i]['link'].find("bbc") != -1:
           helpers.msg(cli, channel, "10,1[BBC WORLD NEWS] %s - %s" % (sorted_entries[i]['title'],tinyurl.create_one(sorted_entries[i]['link'])))
        elif sorted_entries[i]['link'].find("jazeera") != -1:
             helpers.msg(cli, channel, "10,1[AJE] %s - %s" % (sorted_entries[i]['title'],tinyurl.create_one(sorted_entries[i]['link'])))
        elif sorted_entries[i]['link'].find("cnn") != -1:
             helpers.msg(cli, channel, "10,1[CNN] %s - %s" % (sorted_entries[i]['title'],tinyurl.create_one(sorted_entries[i]['link'])))
        elif sorted_entries[i]['link'].find("reuters") != -1:
             helpers.msg(cli, channel, "10,1[REUTERS BUSINESS] %s - %s" % (sorted_entries[i]['title'],tinyurl.create_one(sorted_entries[i]['link'])))
        elif sorted_entries[i]['link'].find("slashdot") != -1:
             helpers.msg(cli, channel, "10,1[\.] %s - %s" % (sorted_entries[i]['title'],tinyurl.create_one(sorted_entries[i]['link'])))
        elif sorted_entries[i]['link'].find("wired") != -1:
             helpers.msg(cli, channel, "10,1[WIRED] %s - %s" % (sorted_entries[i]['title'],tinyurl.create_one(sorted_entries[i]['link'])))
        elif sorted_entries[i]['link'].find("popsci") != -1:
             helpers.msg(cli, channel, "10,1[POPULAR SCIENCE] %s - %s" % (sorted_entries[i]['title'],tinyurl.create_one(sorted_entries[i]['link'])))
        elif sorted_entries[i]['link'].find("telegraph") != -1:
             helpers.msg(cli, channel, "10,1[TELEGRAPH] %s - %s" % (sorted_entries[i]['title'],tinyurl.create_one(sorted_entries[i]['link'])))
        elif sorted_entries[i]['link'].find("google") != -1:
             helpers.msg(cli, channel, "10,1[GOOGLE NEWS] %s - %s" % (sorted_entries[i]['title'],tinyurl.create_one(sorted_entries[i]['link'])))
        elif sorted_entries[i]['link'].find("hitb") != -1:
             helpers.msg(cli, channel, "10,1[HACK IN THE BOX] %s - %s" % (sorted_entries[i]['title'],tinyurl.create_one(sorted_entries[i]['link'])))
        elif sorted_entries[i]['link'].find("dw-world") != -1:
             helpers.msg(cli, channel, "10,1[DEUTSCHE WELLE ENG] %s - %s" % (sorted_entries[i]['title'],tinyurl.create_one(sorted_entries[i]['link'])))
        elif sorted_entries[i]['link'].find("pcgamer") != -1:
             helpers.msg(cli, channel, "10,1[PC GAMER] %s - %s" % (sorted_entries[i]['title'],tinyurl.create_one(sorted_entries[i]['link'])))
        elif sorted_entries[i]['link'].find("eluniversal") != -1:
             helpers.msg(cli, channel, "10,1[El Universal] %s - %s" % (sorted_entries[i]['title'],tinyurl.create_one(sorted_entries[i]['link'])))
        elif sorted_entries[i]['link'].find("nhk") != -1:
             helpers.msg(cli, channel, "10,1[NHK] %s - %s" % (sorted_entries[i]['title'],tinyurl.create_one(sorted_entries[i]['link'])))
        elif sorted_entries[i]['link'].find("france24") != -1:
             helpers.msg(cli, channel, "10,1[FRANCE24] %s - %s" % (sorted_entries[i]['title'],tinyurl.create_one(sorted_entries[i]['link'])))
        elif sorted_entries[i]['link'].find("affaritaliani") != -1:
             helpers.msg(cli, channel, "10,1[AFFARITALIANI] %s - %s" % (sorted_entries[i]['title'],tinyurl.create_one(sorted_entries[i]['link'])))
        elif sorted_entries[i]['link'].find("xinhuanet") != -1:
             helpers.msg(cli, channel, "10,1[XINHUA] %s - %s" % (sorted_entries[i]['title'],tinyurl.create_one(sorted_entries[i]['link'])))
        elif sorted_entries[i]['link'].find("chosun") != -1:
             helpers.msg(cli, channel, "10,1[CHOSUN] %s - %s" % (sorted_entries[i]['title'],tinyurl.create_one(sorted_entries[i]['link']))) 
        time.sleep(15)

newsfeed()
